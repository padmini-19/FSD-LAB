import { Routes, Route, Link } from "react-router-dom";
import "./App.css";

function Home() {
  return (
    <div className="home">
      <h1>CourseBlog</h1>
      <p>Welcome to the CourseBlog website.</p>

      <Link to="/courses" className="button">
        View Courses
      </Link>
    </div>
  );
}

function Courses() {
  return (
    <main className="courses-page">
      <div className="container">

        {/* Page Header */}
        <div className="courses-header">
          <span>LEARN WITH US</span>

          <h1>Explore Our Courses</h1>

          <p>
            Build practical skills with our carefully designed
            courses. Choose a course and start learning today.
          </p>
        </div>

        {/* Course Cards */}
        <div className="courses-grid">

          {/* Course 1 */}
          <div className="course-card">
            <div className="course-card-image react-course">
              <span>WEB DEVELOPMENT</span>
            </div>

            <div className="course-card-content">
              <div className="course-info">
                <span>Beginner</span>
                <span>•</span>
                <span>8 Weeks</span>
              </div>

              <h2>Complete React Development</h2>

              <p>
                Learn React from the basics and build modern,
                responsive web applications using components,
                hooks and React Router.
              </p>

              <div className="course-details">
                <span>👨‍💻 John Smith</span>
                <span>📚 32 Lessons</span>
              </div>

              <Link
                to="/blog/react"
                className="course-button"
              >
                View Course →
              </Link>
            </div>
          </div>

          {/* Course 2 */}
          <div className="course-card">
            <div className="course-card-image javascript-course">
              <span>JAVASCRIPT</span>
            </div>

            <div className="course-card-content">
              <div className="course-info">
                <span>Beginner</span>
                <span>•</span>
                <span>6 Weeks</span>
              </div>

              <h2>JavaScript Fundamentals</h2>

              <p>
                Master JavaScript fundamentals including
                variables, functions, arrays, objects,
                ES6 features and asynchronous programming.
              </p>

              <div className="course-details">
                <span>👩‍💻 Sarah Wilson</span>
                <span>📚 28 Lessons</span>
              </div>

              <Link
                to="/blog/javascript"
                className="course-button"
              >
                View Course →
              </Link>
            </div>
          </div>

          {/* Course 3 */}
          <div className="course-card">
            <div className="course-card-image html-course">
              <span>FRONTEND</span>
            </div>

            <div className="course-card-content">
              <div className="course-info">
                <span>Beginner</span>
                <span>•</span>
                <span>5 Weeks</span>
              </div>

              <h2>HTML & CSS Complete Guide</h2>

              <p>
                Learn how to create beautiful responsive
                websites using HTML5, CSS3, Flexbox,
                Grid and modern responsive design.
              </p>

              <div className="course-details">
                <span>👨‍💻 Michael Brown</span>
                <span>📚 24 Lessons</span>
              </div>

              <Link
                to="/blog/html-css"
                className="course-button"
              >
                View Course →
              </Link>
            </div>
          </div>

          {/* Course 4 */}
          <div className="course-card">
            <div className="course-card-image python-course">
              <span>PROGRAMMING</span>
            </div>

            <div className="course-card-content">
              <div className="course-info">
                <span>Beginner</span>
                <span>•</span>
                <span>7 Weeks</span>
              </div>

              <h2>Python for Beginners</h2>

              <p>
                Start programming with Python and learn
                variables, loops, functions, classes and
                how to build simple real-world projects.
              </p>

              <div className="course-details">
                <span>👨‍💻 David Lee</span>
                <span>📚 30 Lessons</span>
              </div>

              <Link
                to="/blog/python"
                className="course-button"
              >
                View Course →
              </Link>
            </div>
          </div>

        </div>
      </div>
    </main>
  );
}
function Blog() {
  return (
    <div className="page">
      <h1>Blog</h1>
      <p>Read our latest course articles.</p>

      <Link to="/" className="button">
        Back Home
      </Link>
    </div>
  );
}

function App() {
  return (
    <>
      <nav className="navbar">
        <Link to="/" className="logo">
          Course<span>Blog</span>
        </Link>

        <div className="links">
          <Link to="/">Home</Link>
          <Link to="/courses">Courses</Link>
          <Link to="/blog">Blog</Link>
        </div>
      </nav>

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courses" element={<Courses />} />
        <Route path="/blog" element={<Blog />} />
      </Routes>
    </>
  );
}

export default App;