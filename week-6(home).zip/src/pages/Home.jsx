function Home() {
  return (
    <div className="page">
      <h1>Welcome to My Website</h1>

      <p>
        This is the home page of my multi-page React application.
      </p>

      <p>
        This website is created using React and React Router.
        You can navigate between different pages using the menu.
      </p>

      <h2>Explore Our Website</h2>

      <p>
        Learn more about us on the About page or contact us
        through the Contact page.
      </p>
    </div>
  );
}

export default Home;