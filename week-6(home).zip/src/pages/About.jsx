function About() {
  return (
    <div className="page">
      <h1>About Us</h1>

      <p>
        Welcome to our website! This project is created as a
        React application.
      </p>

      <p>
        We use React Router to create multiple pages and allow
        users to navigate between them without reloading the page.
      </p>

      <h2>Our Technologies</h2>

      <ul>
        <li>React</li>
        <li>React Router</li>
        <li>JavaScript</li>
        <li>HTML and CSS</li>
      </ul>
    </div>
  );
}

export default About;