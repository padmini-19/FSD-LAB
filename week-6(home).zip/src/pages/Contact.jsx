function Contact() {
  return (
    <div className="page">
      <h1>Contact Us</h1>

      <p>
        If you have any questions, feel free to contact us.
      </p>

      <h3>Contact Information</h3>

      <p>Email: mywebsite@gmail.com</p>
      <p>Phone: +91 9876543210</p>
      <p>Location: Hyderabad, India</p>

      <h3>Thank You!</h3>

      <p>We will be happy to hear from you.</p>
    </div>
  );
}

export default Contact;